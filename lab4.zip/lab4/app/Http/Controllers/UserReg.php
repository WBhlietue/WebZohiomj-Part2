<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;

session_start();

class UserReg extends Controller
{

    public function index()
    {
        return view("view");
    }
    public function create()
    {
        return view("insert");
    }
    public function store(request $request)
    {
        if (isset($_POST["name"]))
        {
            $id = 0;
            $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
            if (isset($_SESSION["id"]))
            {
                $id = $_SESSION["id"];
                $_SESSION["id"] = $id + 1;
            }
            else
            {
                $_SESSION["id"] = 0;
            }
            $data[] = [
                $id,
                $_POST["name"],
                $_POST["surName"],
                $_POST["email"],
            ];
            $_SESSION["data"] = $data;
            // $_SESSION["id"] = 0;
        }
        echo "<script>window.location.href='/users'</script>";
    }
    public function show($id)
    {
        return view("show", ["id" => $id]);
    }
    public function edit($id)
    {
        return view("edit", ["id" => $id]);
        // echo "edit " . $id;
    }
    public function update(request $require, $id)
    {
        if (isset($_POST["name"]))
        {
            $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];

            $data[$id] = [
                $id,
                $_POST["name"],
                $_POST["surName"],
                $_POST["email"],
            ];

            $_SESSION["data"] = $data;
        }
        echo "<script>window.location.href='/users'</script>";
    }
    public function destroy($id)
    {
        $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
        for($i = 0; $i < count($data); $i++){
            if($data[$i][0] == $id){
                array_splice($data, $i, 1);
                break;
            }
        }
        $_SESSION["data"] = $data;
        echo "<script>window.location.href='/users'</script>";
    }
}
