<html>

<body>


    <form action="/users/<?php echo $id ?>" method="post">


        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Нэр</th>
                <th>Овог</th>
                <th>Цахим шуудан</th>
            </tr>
            <?php
            $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
            foreach ($data as $item)
            {
                if ($item[0] == $id)
                {
                    echo "<tr>";
                    echo "<td>$item[0]</td>";
                    echo "<td><input name='name' value='$item[1]'/></td>";
                    echo "<td><input name='surName' value='$item[2]'/></td>";
                    echo "<td><input name='email' value='$item[3]'/></td>";
                    echo "</tr>";
                }
            }
            ?>
        </table>
        <br/>
        <input type="submit" value="Save">

    </form>

    <form action="/users/<?php echo $id ?>/delete" method="post">

        <input type="hidden" name="_method" value="delete" />

        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        
        <input type="submit" value="Delete user">

    </form>
    <button onclick="Click()">Back</button>
            <script>
                function Click(){
                    var str = window.location.href.substr(0, window.location.href.length - 5)
                    window.location.href  =str
                    
                }
            </script>
</body>

</html>