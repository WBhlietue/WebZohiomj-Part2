<html lang="en">

<body>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Нэр</th>
            <th>Овог</th>
            <th>Цахим шуудан</th>
        </tr>
        <?php
        $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
        foreach ($data as $item)
        {
            if ($item[0] == $id)
            {
                echo "<tr>";
                foreach ($item as $value)
                {
                    echo "<td>$value</td>";
                }
                echo "</tr>";
            }
        }
        ?>
    </table>
    <br />
    <button onclick="window.location.href += '/edit'">Edit</button>
    <button onclick="Click()">Back</button>
    <script>
        function Click() {
            var str = window.location.href.substr(0, window.location.href.length - 2)
            window.location.href = str

        }
    </script>
</body>

</html>