<html>

<body>
    <form action='/users' method='post'>
        <label>Нэр</label>
        <br />
        <input name="name" />
        <br />
        <label>Овог</label>
        <br />
        <input name="surName" />
        <br />
        <label>Цахим шуудан</label>
        <br />
        <input name="email" />
        <br />
        <br />
        <br />
        <input type='hidden' name='_token' value='<?php echo csrf_token(); ?>'>
        <input type='submit' value='Add user'>
    </form>
    <button onclick="Click()">Back</button>
    <script>
        function Click() {
            var str = window.location.href.substr(0, window.location.href.length - 7)
            window.location.href = str

        }
    </script>
</body>

</html>