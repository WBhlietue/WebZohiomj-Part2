

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .main {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .main table {
            margin-top: 50px;
            font-size: 25px;
            font-family: "Arial";
        }
        button{
            font-size: 30px;
        }
    </style>
</head>
<body>
<div class="main">
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Нэр</th>
                <th>Овог</th>
                <th>Цахим шуудан</th>
                <th></th>
            </tr>
            <?php
            $data = isset($_SESSION["data"]) ? $_SESSION["data"] : [];
            foreach ($data as $item)
            {
                echo "<tr>";
                foreach ($item as $value)
                {
                    echo "<td>$value</td>";
                }
                echo "<td><button onclick=\"window.location.href='users/".$item[0]."'\">Show</button></td>";
                echo "</tr>";
            }
            ?>
        </table>
        <button onclick="window.location.href='users/create'">Create</button>
    </div>
</body>
</html>